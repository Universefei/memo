#include <stdio.h>
#include "ogr_core.h"
int main(int argc, char** argv){
     printf("%s", "Hello, Linux World!\n");
     return 0;
}
